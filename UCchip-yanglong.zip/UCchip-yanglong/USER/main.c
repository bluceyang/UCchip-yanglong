#include "delay.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"	 
#include "adc.h"
#include "beep.h"
#include "led.h"


 int main(void)
 {	 
    u16 adcs,adcw,a,b,t;
	float temp,s,w;
	int i=0;
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_Configuration(); 	 //�жϳ�ʼ��
	uart_init(9600);	 	//��������9600
	LCD_Init();			 	
	Adc_Init();		  		//ADC��ʼ��
	BEEP_Init();
	LED_Init();
	POINT_COLOR=RED;//??????? 
	LCD_ShowString(60,50,200,16,16,"WarShip STM32");	
	LCD_ShowString(60,70,200,16,16,"ADC TEST");	

	POINT_COLOR=BLUE;
    LCD_ShowString(60,90 ,200,16,16,"ADC_sdVAL:0.000V");	      
	LCD_ShowString(60,110,200,16,16,"ADC_wdVOL:0.000V");	
	LCD_ShowString(60,130,200,16,16,"adcs:  .  %");	      
	LCD_ShowString(60,150,200,16,16,"adcw:  .  C");	
	while(1)
	{
		adcs=Get_Adc_Average(ADC_Channel_0,10);  //pa0
		adcw=Get_Adc_Average(ADC_Channel_1,10);   //pa1
		s=(float)adcs*(3.3/4096); 
		w=(float)adcw*(3.3/4096);  //S  W Ϊ������ѹֵ
        t=s;
        LCD_ShowNum(155,90,t,2,16);	
        t=(s-t)*100;
        LCD_ShowNum(172,90,t,2,16);	
        t=w;
        LCD_ShowNum(155,110,t,2,16);
        t=(w-t)*100;
        LCD_ShowNum(172,110,t,2,16);
 
		 w=w/0.01;
		 adcs=s;
		 adcw=w;
		 temp=s/0.03;
		 if(temp>70)
		 {
			 BEEP=1;
             LED0=0;       
            }
		else
		{ 
			BEEP=0;
            LED0=1;
             }
		if(i%8==0)
		printf("Shidu:%f\r\nWendu:%f\r\n",temp,w);  //���ڴ�ӡ�¶�ʪ��ֵ
		LCD_ShowNum(120,150,adcw,2,16);	
   
        b=(w-adcw)*100;
        LCD_ShowNum(60+60,150,b,2,16);	
        a=temp;                                     
		temp-=(u8)temp;//ȡ��������				    				  
		LCD_ShowxNum(100,130,a,2,16,0);
		LCD_ShowNum(120,130,temp*100,2,16);	//��ʾʪС������
	    delay_ms(2000);	
	}
 }
